<!-- Button trigger modal -->
<!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Launch demo modal
</button>
 -->
<!-- Modal -->
<div class="modal fade remove-style" id="bola" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-body no-gutters">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <div class="col-12">
          <div class="pg-advisor">
            <div class="row">

              <!-- <div class="col-lg-4">
                <div class="pg-advisor__thumb">
                  <img src="images/team/azubuike.jpg" alt="Advisor Details Thumb">
                </div>
              </div> -->

              <div class="col-lg-12">
                <div class="pg-advisor__details">
                  <h2>BOLARINWA OMOLOLA</h2>
                  <h5>DIRECTOR</h5>
                  <p>
                    Mrs. Bolarinwa is a Law graduate of the Obafemi Awolowo University, Ile Ife with over 15 years post bar experience. Omolola is well grounded in litigation, company incorporation and secretarial services. In addition to her law experience, Lola has experience in the finance sector covering the areas of loan processing and loan recovery. She holds a Master’s degree in Law from the University of Lagos and also a member of the Institute of Chartered Secretaries and Administration of Nigeria (ICSAN). She brings her legal, administrative and business acumen to the board of Lukefield Finance Limited.



                  </p>
                  
                  
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>