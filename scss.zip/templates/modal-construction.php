<!-- Button trigger modal -->
<!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Launch demo modal
</button>
 -->
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-body">
         <div class="row no-gutters">
           <div class="col-lg-6 bg-success">
             <div class="modal-cover text-center p-3">
               <h1>Welcome To Ukefield Finance Limited</h1>
               <h2>This site is still under construction</h2>
             </div>
           </div>
           <div class="col-lg-6">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
             <img src="images/modal-img.jpg" alt="" class="img-fluid">
           </div>
         </div>
      </div>
    </div>
  </div>
</div>