<!-- JS Files -->
<script src="js/vendor/jquery-3.2.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/plugins.js"></script>
<script src="js/active.js"></script>
<script src="js/scripts.js"></script>
<script src="js/ajax-mail.js"></script>
<script src="js/custom-scripts.js"></script>
<script src="js/custom-js.js"></script>

<!-- <script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
<script src="assets/js/jquery.mixitup.js"></script>
<script src="assets/js/wow.js"></script>
<script src="assets/js/jquery.nav.js"></script>
<script src="assets/js/scrolling-nav.js"></script>
<script src="assets/js/jquery.easing.min.js"></script>
<script src="assets/js/jquery.counterup.min.js"></script>  
<script src="assets/js/nivo-lightbox.js"></script>     
<script src="assets/js/jquery.magnific-popup.min.js"></script>     
<script src="assets/js/waypoints.min.js"></script>   
<script src="assets/js/jquery.slicknav.js"></script>
<script src="assets/js/main.js"></script>
<script src="assets/js/form-validator.min.js"></script>
<script src="assets/js/contact-form-script.min.js"></script>
<script src="assets/js/custom-js.js"></script> -->
  