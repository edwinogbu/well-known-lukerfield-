<!doctype html>
<html class="no-js" lang="zxx">

<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>Fsulting - Financial Consulting Bootstrap 4 Template</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Favicons -->
	<link rel="shortcut icon" href="images/favicon.ico">
	<link rel="apple-touch-icon" href="images/icon.png">

	<!-- Google font (font-family: 'Poppins', sans-serif;) -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,400i,500,600,700" rel="stylesheet">
	<!-- Google font (font-family: 'Work Sans', sans-serif;) -->
	<link href="https://fonts.googleapis.com/css?family=Work+Sans:300,400,500,600,700" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/plugins.css">
	<link rel="stylesheet" href="style.css">

	<!-- Cusom css -->
	<link rel="stylesheet" href="css/custom.css">

	<!-- Modernizer js -->
	<script src="js/vendor/modernizr-3.5.0.min.js"></script>
</head>

<body>
	<!--[if lte IE 9]>
		<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
	<![endif]-->

	<!-- Add your site or application content here -->

	<div class="fakeloader"></div>

	<!-- Main wrapper -->
	<div class="wrapper" id="wrapper">

		<!-- Header -->
		<header id="header" class="header sticky--header">

			<!-- Header Top Area -->
			<div class="header__top bg--blue">
				<div class="container">
					<div class="header__top__inner">
						<ul class="header__top__info">
							<li>
								<a href="#"><i class="fa fa-phone"></i>01354 568 787</a>
							</li>
							<li>
								<a href="#">
									<i class="fa fa-envelope-o"></i> info@fsulting.com</a>
							</li>
						</ul>
						<div class="header__top__button">
							<a class="cr-btn cr-btn--lg" href="appointment.html">
								<span>Make an appointment</span>
							</a>
						</div>
					</div>
				</div>
			</div>
			<!--// Header Top Area -->

			<!-- Header Bottom Area -->
			<div class="header__bottom bg--white">
				<div class="container d-none d-lg-block">
					<div class="header__bottom__inner">
						<div class="header__logo">
							<a href="index.html">
								<img src="images/logo/logo-theme.png" alt="header logo">
							</a>
						</div>

						<!-- Main Navigation -->
						<nav id="main-navigation" class="header__menu main-navigation">
							<ul>
								<li class="cr-dropdown">
									<a href="index.html">HOME</a>
									<ul class="cr-dropdown-menu">
										<li>
											<a href="index.html">Homepage Classic</a>
										</li>
										<li>
											<a href="index-boxed-layout.html">Homepage Boxed Layout</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="about-us.html">ABOUT</a>
								</li>
								<li class="cr-dropdown">
									<a href="portfolio.html">PORTFOLIO</a>
									<ul class="cr-dropdown-menu">
										<li>
											<a href="portfolio.html">Portfolio Grid</a>
										</li>
										<li>
											<a href="portfolio-details.html">Portfolio Details</a>
										</li>
									</ul>
								</li>
								<li class="cr-dropdown">
									<a href="services.html">SERVICE</a>
									<ul class="cr-dropdown-menu">
										<li>
											<a href="services.html">Services</a>
										</li>
										<li>
											<a href="single-service.html">Single Service</a>
										</li>
									</ul>
								</li>
								<li class="cr-dropdown">
									<a href="#">PAGES</a>
									<ul class="cr-dropdown-menu">
										<li>
											<a href="about-us.html">ABOUT</a>
										</li>
										<li>
											<a href="blog.html">BLOG</a>
											<ul class="cr-sub-dropdown-menu">
												<li>
													<a href="blog.html">Blog</a>
												</li>
												<li>
													<a href="blog-with-right-sidebar.html">Blog With Right Sidebar</a>
												</li>
												<li>
													<a href="blog-with-left-sidebar.html">Blog With Left Sidebar</a>
												</li>
												<li>
													<a href="blog-details.html">Blog Details</a>
												</li>
												<li>
													<a href="blog-details-with-left-sidebar.html">Blog Details With Left Sidebar</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="features.html">FEATURES</a>
										</li>
										<li>
											<a href="services.html">SERVICE</a>
											<ul class="cr-sub-dropdown-menu">
												<li>
													<a href="services.html">Services</a>
												</li>
												<li>
													<a href="single-service.html">Single Service</a>
												</li>
											</ul>
										</li>
										<li>
											<a href="team.html">Team</a>
										</li>
										<li>
											<a href="team-details.html">Team Details</a>
										</li>
										<li>
											<a href="appointment.html">Appointment</a>
										</li>
									</ul>
								</li>
								<li class="cr-dropdown">
									<a href="blog.html">BLOG</a>
									<ul class="cr-dropdown-menu">
										<li>
											<a href="blog.html">Blog</a>
										</li>
										<li>
											<a href="blog-with-right-sidebar.html">Blog With Right Sidebar</a>
										</li>
										<li>
											<a href="blog-with-left-sidebar.html">Blog With Left Sidebar</a>
										</li>
										<li>
											<a href="blog-details.html">Blog Details</a>
										</li>
										<li>
											<a href="blog-details-with-left-sidebar.html">Blog Details With Left Sidebar</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="contact.html">CONTACT</a>
								</li>
							</ul>
						</nav>
						<!--// Main Navigation -->

					</div>
				</div>

				<!-- Mobile Menu -->
				<div class="container d-block d-lg-none">
					<div class="mobile-menu clearfix d-md-block d-lg-none">
						<a class="mobile-logo" href="index.html">
							<img src="images/logo/logo-theme.png" alt="logo">
						</a>
					</div>
				</div>
				<!-- //Mobile Menu -->

			</div>
			<!--// Header Bottom Area -->

		</header>
		<!-- //Header -->

		<!-- Breadcrumb Area -->
		<div id="cr-breadcrumb-area" class="cr-breadcrumb-area bg-image--2 section-padding--md" data-overlay="8">
			<div class="container">
				<div class="cr-breadcrumb">
					<div class="cr-breadcrumb__left">
						<h2>Blog Details</h2>
						<p>Nihil culpa beatae officiis temporibus vel vel asperiores in ut.</p>
					</div>
					<div class="cr-breadcrumb__right">
						<ul class="cr-breadcrumb__pagination">
							<li>
								<a href="index.html">Home</a>
							</li>
							<li>
								<a href="blog-with-right-sidebar.html">Blog</a>
							</li>
							<li>Blog Details</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!--// Breadcrumb Area -->

		<!-- Page Conent -->
		<main class="page-content">

			<!-- BLogs grid -->
			<div class="cr-section pg-blogs-area section-padding--xlg bg--white">
				<div class="container">
					<div class="row">

						<!-- BLog Details -->
						<div class="col-lg-8">
							<article class="pg-blog">
								<div class="pg-blog-thumb">
									<img src="images/blog/blogdetails/blog-details-1.jpg" alt="blog details thumb">
								</div>
								<div class="pg-blog-main">
									<h2 class="pg-blog-title">Why Private College Admissions Consulting Has Become the Rule</h2>
									<ul class="pg-blog-meta">
										<li>OCTOBER 26.</li>
										<li><a href="#">RASEL MAHMUD.</a></li>
										<li><a href="#">4 comments</a></li>
									</ul>
									<div class="pg-blog-content clearfix">
										<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical
											Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at
											Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem
											Ipsum passage, and going through the cites of thword in classical literature, discored the undoubtable
											source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes
											of Good and Evil) by Cicero, written in 45 BC</p>
										<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections
											1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact
											original form, accompanied by English versions from the 1914 translation by H. Rac.Ipsum comes from sections
											1.10.32 and 1.10.33 of "dFinibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero</p>
										<ol class="alignleft">
											<li>Maecenas in neque et velit rutrum molestie</li>
											<li>Sed et sem vel est suscipit vehicula quis convallis</li>
											<li>Maecenas eu mi dapibus, ullamcorper augue sit</li>
											<li>Morbi quis sapien sed odio mollis sodales</li>
											<li>Donec aliquet leo nec orci facilisis varius el est</li>
										</ol>
										<img src="images/blog/blogdetails/blog-details-field.jpg" alt="blog details field" class="alignright">
									</div>
								</div>
							</article>
							<div class="pg-blog-block pg-blog-author">
								<h4 class="small-title">Author</h4>
								<div class="pg-blog-authorbox">
									<div class="pg-blog-authoriamge">
										<img src="images/blog/blogdetails/authorimage/authorimage-1.png" alt="author image">
									</div>
									<div class="pg-blog-authordes">
										<h6>simon doal</h6>
										<p>But I must explain to you how all this mistaken idea of denouncing sure and ising pain borand I will give
											you a complete account</p>
									</div>
								</div>
							</div>
							<div class="pg-blog-block pg-blog-social">
								<div class="pg-blog-social-icons">
									<h6>Share: </h6>
									<div class="social-icons social-icons--rounded-color">
										<ul>
											<li class="facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
											<li class="twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
											<li class="pinterest"><a href="#"><i class="fa fa-pinterest"></i></a></li>
											<li class="linkedin"><a href="#"><i class="fa fa-linkedin"></i></a></li>
										</ul>
									</div>
								</div>
								<div class="pg-blog-tags">
									<h6>Tags: </h6>
									<ul>
										<li><a href="blog.html">Builder</a></li>
										<li><a href="blog.html">Market</a></li>
										<li><a href="blog.html">Construt</a></li>
									</ul>
								</div>
							</div>
							<div class="pg-blog-block commentlist">
								<h4 class="small-title">Comments</h4>
								<div class="comment">
									<div class="pg-blog-authoriamge">
										<img src="images/blog/blogdetails/authorimage/authorimage-2.png" alt="author image">
									</div>
									<div class="comment__content">
										<div class="comment__content__top">
											<h6>Alvaro Santos</h6>
											<span>08 Jun 2017</span>
										</div>
										<a href="#" class="reply">Reply</a>
										<div class="comment__content__bottom">But I must explain to you how all this mistaken idea of denouncing
											pleasure and ising pain borand I will give you a complete account of the system</div>
									</div>
								</div>
								<div class="comment reply">
									<div class="pg-blog-authoriamge">
										<img src="images/blog/blogdetails/authorimage/authorimage-3.png" alt="author image">
									</div>
									<div class="comment__content">
										<div class="comment__content__top">
											<h6>Julia homas</h6>
											<span>06 Jun 2017</span>
										</div>
										<a href="#" class="reply">Reply</a>
										<div class="comment__content__bottom">But I must explain to you how all this mistaken idea of denounng
											pleasure and ising pain borand I will give you a complete</div>
									</div>
								</div>
								<div class="comment">
									<div class="pg-blog-authoriamge">
										<img src="images/blog/blogdetails/authorimage/authorimage-4.png" alt="author image">
									</div>
									<div class="comment__content">
										<div class="comment__content__top">
											<h6>NICOLUS SMITH</h6>
											<span>08 Jun 2017</span>
										</div>
										<a href="#" class="reply">Reply</a>
										<div class="comment__content__bottom">But I must explain to you how all this mistaken idea of denouncing
											pleasure and ising pain borand I will give you a complete account of the system</div>
									</div>
								</div>
							</div>
							<div class="pg-blog-block commentbox">
								<h4 class="small-title">Leave a Comment</h4>
								<form action="#">
									<div class="row">
										<div class="col-lg-6 col-md-6">
											<div class="single-input">
												<label for="commenter-name">Name</label>
												<input type="text" name="commenter-name" id="commenter-name">
											</div>
										</div>
										<div class="col-lg-6 col-md-6">
											<div class="single-input">
												<label for="commenter-email">Email</label>
												<input type="email" name="commenter-email" id="commenter-email">
											</div>
										</div>
										<div class="col-lg-12">
											<div class="single-input">
												<label for="commenter-message">Message</label>
												<textarea name="commenter-message" id="commenter-message" cols="30" rows="5"></textarea>
											</div>
										</div>
										<div class="col-lg-12">
											<div class="single-input">
												<button type="submit" class="cr-btn"><span>Send Now</span></button>
											</div>
										</div>
									</div>
								</form>
							</div>
						</div>
						<!--// BLog Details -->

						<!-- Sidebar -->
						<div class="col-lg-4">
							<div class="widgets sidebar-widgets">
								<!-- Single Widget -->
								<section class="single-widget widget-about">
									<header class="widget-about__thumb">
										<img src="images/others/about-widget.jpg" alt="about widget thumb">
									</header>
									<footer class="widget-about__content">
										<p>On the other hand, dislike men who are so beguiled and demoralized by the charms of pleasure of the</p>
										<h6>Robart Rofiq Bali</h6>
										<h6><small>UI UX Designer</small></h6>
										<div class="social-icons">
											<ul>
												<li class="facebook"><a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a></li>
												<li class="twitter"><a href="https://twitter.com/"><i class="fa fa-twitter"></i></a></li>
												<li class="vimeo"><a href="https://www.vimeo.com/"><i class="fa fa-vimeo"></i></a></li>
												<li class="pinterest"><a href="https://pinterest.com"><i class="fa fa-pinterest"></i></a></li>
											</ul>
										</div>
									</footer>
								</section>
								<!--// Single Widget -->

								<!-- Single Widget -->
								<section class="single-widget widget-search">
									<h6>Search</h6>
									<form action="#">
										<input type="text" placeholder="Search Keyword">
										<button type="submit"><i class="fa fa-search"></i></button>
									</form>
								</section>
								<!--// Single Widget -->

								<!-- Single Widget -->
								<section class="single-widget widget-recentpost">
									<h6>Recent Post</h6>
									<ul>
										<li>
											<a class="widget-recentpost__thumb" href="blog-details.html"><img src="images/blog/thumbnail/blog-thumbnail-1.png"
												 alt="blog thumbnail"></a>
											<div class="widget-recentpost__content">
												<span class="date">october 18, 2018</span>
												<h6><a href="blog-details.html">Various tax guide line for every one</a></h6>
											</div>
										</li>
										<li>
											<a class="widget-recentpost__thumb" href="blog-details.html"><img src="images/blog/thumbnail/blog-thumbnail-2.png"
												 alt="blog thumbnail"></a>
											<div class="widget-recentpost__content">
												<span class="date">october 16, 2018</span>
												<h6><a href="blog-details.html">financial development for startup business</a></h6>
											</div>
										</li>
										<li>
											<a class="widget-recentpost__thumb" href="blog-details.html"><img src="images/blog/thumbnail/blog-thumbnail-3.png"
												 alt="blog thumbnail"></a>
											<div class="widget-recentpost__content">
												<span class="date">october 14, 2018</span>
												<h6><a href="blog-details.html">irs tax payer protection system</a></h6>
											</div>
										</li>
										<li>
											<a class="widget-recentpost__thumb" href="blog-details.html"><img src="images/blog/thumbnail/blog-thumbnail-4.png"
												 alt="blog thumbnail"></a>
											<div class="widget-recentpost__content">
												<span class="date">october 12, 2018</span>
												<h6><a href="blog-details.html">in house training for corporate tax</a></h6>
											</div>
										</li>
									</ul>
								</section>
								<!--// Single Widget -->

								<!-- Single Widget -->
								<section class="single-widget widget-categories">
									<h6>Categories</h6>
									<ul>
										<li><a href="blog-with-right-sidebar.html">TAX <span>(20)</span></a></li>
										<li><a href="blog-with-right-sidebar.html">Business <span>(18)</span></a></li>
										<li><a href="blog-with-right-sidebar.html">Finance <span>(40)</span></a></li>
										<li><a href="blog-with-right-sidebar.html">Irs payer <span>(30)</span></a></li>
										<li><a href="blog-with-right-sidebar.html">TAX Calculation <span>(66)</span></a></li>
										<li><a href="blog-with-right-sidebar.html">MUTUAL FUND SCHEMS <span>(99)</span></a></li>
									</ul>
								</section>
								<!--// Single Widget -->

								<!-- Single Widget -->
								<section class="single-widget widget-newsletter">
									<h6>Newsletter</h6>
									<form action="#">
										<input type="text" placeholder="Enter your E-mail ">
										<button type="submit"><i class="fa fa-paper-plane-o"></i></button>
									</form>
								</section>
								<!--// Single Widget -->

								<!-- Single Widget -->
								<section class="single-widget widget-instagram">
									<h6>Instagram</h6>
									<ul id="sidebar-instagram-feed"></ul>
								</section>
								<!--// Single Widget -->

								<!-- Single Widget -->
								<section class="single-widget widget-social-icon">
									<h6>Social Icons</h6>
									<ul>
										<li class="facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li class="twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
										<li class="pinterest"><a href="#"><i class="fa fa-pinterest"></i></a></li>
										<li class="vimeo"><a href="#"><i class="fa fa-vimeo"></i></a></li>
									</ul>
								</section>
								<!--// Single Widget -->

								<!-- Single Widget -->
								<section class="single-widget widget-tags">
									<h6>Tags</h6>
									<ul>
										<li><a href="blog-with-right-sidebar.html">Design</a></li>
										<li><a href="blog-with-right-sidebar.html">Print</a></li>
										<li><a href="blog-with-right-sidebar.html">Adobe</a></li>
										<li><a href="blog-with-right-sidebar.html">Development</a></li>
										<li><a href="blog-with-right-sidebar.html">Support</a></li>
										<li><a href="blog-with-right-sidebar.html">Creative</a></li>
									</ul>
								</section>
								<!--// Single Widget -->

							</div>
						</div>
						<!--// Sidebar -->

					</div>
				</div>
			</div>
			<!--// BLogs grid -->

			<!-- Call To Action Area -->
			<section class="cta-area section-padding--md bg--grey--light bg--abstruct-mask">
				<div class="container">
					<div class="row justify-content-center">
						<div class="col-xl-9 col-lg-10">
							<div class="calltoaction text-center">
								<h3>NEED HELP FOR YOUR <span class="color--theme">FINANCIAL CONSULTING ?</span>
								</h3>
								<p>Perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem
									aperiam, eaque ipsa Neque.</p>
								<div class="calltoaction-button mt-4">
									<span class="calltoaction-icon"><i class="flaticon-phone"></i></span>
									<a href="callto://+00812548359874">+008 12548 359 874</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!--// Call To Action Area -->

		</main>
		<!-- //Page Conent -->

		<!-- Footer Area -->
		<footer id="footer" class="footer-area fixed--footer">

			<!-- Footer Widgets Area -->
			<div class="footer-area__widgets section-padding--lg bg--dark--light">
				<div class="container">
					<div class="widget-area footer--widgets">

						<!-- Single Widget -->
						<div class="widget widget-about">
							<div class="footer-area__logo">
								<a href="index.html">
									<img src="images/logo/logo-footer.png" alt="footer logo">
								</a>
							</div>
							<p>Perspiciatis unde omnis iste natus error sit voluptatem accusantium oloremque laudantium, totam rem
								onsectetur sires
								to obtain pain of itself because</p>
							<div class="social-icons social-icons--rounded">
								<ul>
									<li class="facebook">
										<a href="https://www.facebook.com/">
											<i class="fa fa-facebook"></i>
										</a>
									</li>
									<li class="twitter">
										<a href="https://twitter.com/">
											<i class="fa fa-twitter"></i>
										</a>
									</li>
									<li class="instagram">
										<a href="https://www.instagram.com/">
											<i class="fa fa-instagram"></i>
										</a>
									</li>
									<li class="google-plus">
										<a href="https://plus.google.com/discover">
											<i class="fa fa-google-plus"></i>
										</a>
									</li>
								</ul>
							</div>
						</div>
						<!--// Single Widget -->

						<!-- Single Widget -->
						<div class="widget widget-quick-links">
							<h5 class="widget-title">QUICK LINKS</h5>
							<ul>
								<li>
									<a href="services.html">Our Services</a>
								</li>
								<li>
									<a href="features.html">Features</a>
								</li>
								<li>
									<a href="about-us.html">About Us</a>
								</li>
								<li>
									<a href="#">Help Centre</a>
								</li>
								<li>
									<a href="contact.html">Contact Us</a>
								</li>
							</ul>
						</div>
						<!--// Single Widget -->

						<!-- Single Widget -->
						<div class="widget widget-twitter-feed">
							<h5 class="widget-title">Twitter Feed</h5>
							<ul>
								<li>
									<p>
										<a href="">@Alex Smith</a>, unde omnis te us error sit voluptatem</p>
									<span class="time">
										<a href="#">10 Mins ago</a>
									</span>
								</li>
								<li>
									<p>
										<a href="">@Justin Bieber</a>, unde omnis te us error sit voluptatem</p>
									<span class="time">
										<a href="#">12 Mins ago</a>
									</span>
								</li>
							</ul>
						</div>
						<!--// Single Widget -->

						<!-- Single Widget -->
						<div class="widget widget-contact-info">
							<h5 class="widget-title">Contact Info</h5>
							<ul>
								<li>
									<p>256 Notrh Tower, Western City Mid Town, Las Vagas, USA</p>
								</li>
								<li>
									<p>
										<a href="callto://+00812568987789">+008 12568 987 789</a>
									</p>
									<p>
										<a href="callto://+00835687567458">+008 35687 567 458</a>
									</p>
								</li>
								<li>
									<p>
										<a href="mailto://info@fsulting.com">info@fsulting.com</a>
									</p>
									<p>
										<a href="mailto://info@fsulting.com">www.fsulting.com</a>
									</p>
								</li>
							</ul>
						</div>
						<!--// Single Widget -->

					</div>
				</div>
			</div>
			<!--// Footer Widgets Area -->

			<!-- Footer Copyright Area -->
			<div class="footer-area__copyright bg--dark">
				<div class="container">
					<div class="row">
						<div class="col-lg-12">
							<div class="copyright text-center">
								©COPYRIGHT, ALL RIGHTS RESERVED BY
								<a href="#">FSULTING</a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--// Footer Copyright Area -->

		</footer>
		<!-- //Footer Area -->

	</div>
	<!-- //Main wrapper -->

	<!-- JS Files -->
	<script src="js/vendor/jquery-3.2.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/plugins.js"></script>
	<script src="js/active.js"></script>
	<script src="js/scripts.js"></script>
</body>

</html>