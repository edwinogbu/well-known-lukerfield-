<?php require_once('config.php') ?>
<?php require_once(DIRECTORY.'templates/head.php') ?>
<?php require_once(DIRECTORY.'templates/header.php') ?>
<style type="text/css">
	.assign a.btn{
		float:right;

	}
</style>

		<!-- Breadcrumb Area -->
		<div id="cr-breadcrumb-area" class="cr-breadcrumb-area bg-image--2 section-padding--md" data-overlay="8">
			<div class="container">
				<div class="cr-breadcrumb">
					<div class="cr-breadcrumb__left">
						<h2>Career</h2>
					</div>
					<div class="cr-breadcrumb__right">
						<ul class="cr-breadcrumb__pagination">
							<li>
								<a href="index.html">Home</a>
							</li>
							<li>Career</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!--// Breadcrumb Area -->

		<!-- Page Conent -->
		<main class="page-content">

			<!-- Contact Area -->
			<section id="about-area" class="cr-section about-area bg--white section-padding--xlg">
				<div class="container">
					<div class="row align-items-center">
						<div class="col-sm-12 col-md-12">
							<div class="about-area__content text-center">
								<h2 class="text-dark">GENUINE <span class="color--theme">CAREERS</span></h4>
								<!-- <h3>LUKEFIELD FINANCIAL <span class="color--theme">SERVICES</span></h3> -->
								<p class="pb-5">Lukefield Finance Limited is a 100 percent Nigerian owned business, The company was Incorporated in 2018,
								Lukefield Finance Ltd was licensed and authorized to operate by the Central Bank of Nigeria in 2018, To provide bespoke services to meet the financial needs and gaps of organizations, To provide bespoke services to meet the financial needs and gaps of organizations</p>
								
							</div>
							<hr class="pb-5">
							<div class="genuine-careers">
								<ul>
									<li>
										<div class="assign pb-5">
											<h4>
												<a href="#">JOB 1</a>
											</h4>
											<span>FULL TIME</span>
											<a href="#" type="button" class="btn btn-success text-white rounded" data-toggle="modal" data-target="#modal1"> VIEW</a>
											<div id="modal1" class="modal fade" role="dialog">
												<div class="modal-dialog text-dark">
													<div class="modal-content">
														<div class="modal-header">
															<button type="button" class="close" data-dismiss="modal">X
															</button>
														</div>
														<div class="modal-body">
															<h4 class="modal-title">JOB 1</h4>
															<h3 class="job-title title-2 text-dark">
																JOB DESCRIPTON
															</h3>
															<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
															tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
															quis nostrud.</p>
															<h3 class="job-title title-2 text-dark">Qualification</h3>
															<h3 class="job-title title-2 text-dark"> METHOD OF APPLICATION:</h3>
															<p>"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
															tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
															quis nostrud."</p>

															<br>
															"     abc123@gmail.com, abc123@gmail.com"
															<h2 class="text-dark">OR</h2>
															<strong>
																"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
															tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
															quis nostrud."
															</strong>
															<p></p>	
														</div>
														<div class="modal-footer">
															<button type="button" class="btn btn-danger" data-dismiss="modal">Close
															</button>
															
														</div>
														
													</div>
													
												</div>
											</div>
											
										</div>
										
									</li>
									<li>
										<div class="assign pb-5">
											<h4>
												<a href="#">JOB 2</a>
											</h4>
											<span>FULL TIME</span>
											<a href="#" type="button" class="btn btn-success text-white rounded" data-toggle="modal" data-target="#modal2"> VIEW</a>
											<div id="modal2" class="modal fade" role="dialog">
												<div class="modal-dialog text-dark">
													<div class="modal-content">
														<div class="modal-header">
															<button type="button" class="close" data-dismiss="modal">X
															</button>
															
														</div>
														<div class="modal-body">
															<h4 class="modal-title">JOB 2</h4>
															<h3 class="job-title title-2 text-dark">
																JOB DESCRIPTON
															</h3>
															<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
															tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
															quis nostrud.</p>
															<h3 class="job-title title-2 text-dark">Qualification</h3>
															<h3 class="job-title title-2 text-dark"> METHOD OF APPLICATION:</h3>
															<p>"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
															tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
															quis nostrud."</p>

															<br>
															"     abc123@gmail.com, abc123@gmail.com"
															<h2 class="text-dark">OR</h2>
															<strong>
																"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
															tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
															quis nostrud."
															</strong>
															<p></p>	
														</div>
														<div class="modal-footer">
															<button type="button" class="btn btn-danger" data-dismiss="modal">Close
															</button>
															
														</div>
														
													</div>
													
												</div>
											</div>
											
										</div>
										
									</li>
									<li>
										<div class="assign pb-5">
											<h4>
												<a href="#">JOB 3</a>
											</h4>
											<span>FULL TIME</span>
											<a href="#" type="button" class="btn btn-success text-white rounded" data-toggle="modal" data-target="#modal3"> VIEW</a>
											<div id="modal3" class="modal fade" role="dialog">
												<div class="modal-dialog text-dark">
													<div class="modal-content">
														<div class="modal-header">
															<button type="button" class="close" data-dismiss="modal">X
															</button>
															<h4 class="modal-title">JOB 3</h4>
														</div>
														<div class="modal-body">
															<h3 class="job-title title-2 text-dark">
																JOB DESCRIPTON
															</h3>
															<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
															tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
															quis nostrud.</p>
															<h3 class="job-title title-2 text-dark">Qualification</h3>
															<h3 class="job-title title-2 text-dark"> METHOD OF APPLICATION:</h3>
															<p>"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
															tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
															quis nostrud."</p>

															<br>
															"     abc123@gmail.com, abc123@gmail.com"
															<h2 class="text-dark">OR</h2>
															<strong>
																"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
															tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
															quis nostrud."
															</strong>
															<p></p>	
														</div>
														<div class="modal-footer">
															<button type="button" class="btn btn-danger" data-dismiss="modal">Close
															</button>
															
														</div>
														
													</div>
													
												</div>
											</div>
											
										</div>
										
									</li>
									<li>
										<div class="assign pb-5">
											<h4>
												<a href="#">JOB 4</a>
											</h4>
											<span>FULL TIME</span>
											<a href="#" type="button" class="btn btn-success text-white rounded" data-toggle="modal" data-target="#modal4"> VIEW</a>
											<div id="modal4" class="modal fade" role="dialog">
												<div class="modal-dialog text-dark">
													<div class="modal-content">
														<div class="modal-header">
															<button type="button" class="close" data-dismiss="modal">X
															</button>
															
														</div>
														<div class="modal-body">
															<h4 class="modal-title">JOB 4</h4>
															<h3 class="job-title title-2 text-dark">
																JOB DESCRIPTON
															</h3>
															<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
															tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
															quis nostrud.</p>
															<h3 class="job-title title-2 text-dark">Qualification</h3>
															<h3 class="job-title title-2 text-dark"> METHOD OF APPLICATION:</h3>
															<p>"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
															tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
															quis nostrud."</p>

															<br>
															"     abc123@gmail.com, abc123@gmail.com"
															<h2 class="text-dark">OR</h2>
															<strong>
																"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
															tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
															quis nostrud."
															</strong>
															<p></p>	
														</div>
														<div class="modal-footer">
															<button type="button" class="btn btn-danger" data-dismiss="modal">Close
															</button>
															
														</div>
														
													</div>
													
												</div>
											</div>
											
										</div>
										
									</li>
									<li>
										<div class="assign pb-5">
											<h4>
												<a href="#">JOB 5</a>
											</h4>
											<span>FULL TIME</span>
											<a href="#" type="button" class="btn btn-success text-white rounded" data-toggle="modal" data-target="#modal5"> VIEW</a>
											<div id="modal5" class="modal fade" role="dialog">
												<div class="modal-dialog text-dark">
													<div class="modal-content">
														<div class="modal-header">
															<button type="button" class="close" data-dismiss="modal">X
															</button>
															
														</div>
														<div class="modal-body">
															<h4 class="modal-title">JOB 5</h4>
															<h3 class="job-title title-2 text-dark">
																JOB DESCRIPTON
															</h3>
															<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
															tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
															quis nostrud.</p>
															<h3 class="job-title title-2 text-dark">Qualification</h3>
															<h3 class="job-title title-2 text-dark"> METHOD OF APPLICATION:</h3>
															<p>"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
															tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
															quis nostrud."</p>

															<br>
															"     abc123@gmail.com, abc123@gmail.com"
															<h2 class="text-dark">OR</h2>
															<strong>
																"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
															tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
															quis nostrud."
															</strong>
															<p></p>	
														</div>
														<div class="modal-footer">
															<button type="button" class="btn btn-danger" data-dismiss="modal">Close
															</button>
															
														</div>
														
													</div>
													
												</div>
											</div>
											
										</div>
										
									</li>
								</ul>
								
							</div>
						</div>
						
					</div>
				</div>
			</section>
			<!-- //About Area -->

		
			



		</main>
		<!-- //Page Conent -->

	  <?php require_once(DIRECTORY."templates/footer.php") ?>

	</div>
	<!-- //Main wrapper -->

	<?php require_once(DIRECTORY."templates/scripts.php") ?>
</body>

</html>